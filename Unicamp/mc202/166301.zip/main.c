/* Nome: Daniela Palumbo
* RA: 166301
* Laboratorio 02 - Matrioshkas Generalizadas */

#include "matrioshka.h"

int main()
{	
	int qtd,i,aux;
	Pilha p;
	novaPilha(*p);
	do{
		/*ler nro de metades*/
		scanf("%d",&qtd);

	/*se for zero sair do programa*/
		if (qtd==0)
			return 0;

		/*ler metades*/
		for (i = 0; i < qtd; ++i)
		{
			scanf("%d",&aux);
			push(*p,aux);
		}

		if (fechaMatrioshka(*p)==1)
			printf("Eh Matrioshka.");
		else
			printf("Nao eh Matrioshka.");
	} while (qtd!=0);
	return 0;
}