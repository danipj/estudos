/* Nome: Daniela Palumbo
* RA: 166301
* Laboratorio 02 - Matrioshkas Generalizadas */

#ifndef PILHA_H_
#define PILHA_H_

#include <stdio.h>
#include <stdlib.h>

#define MAX_STACK_SIZE 10000000

typedef struct Pilha {
    int array[MAX_STACK_SIZE];
    int top;
} Pilha;

void push(Pilha *p, int n);
int pop(Pilha *p);
void printPilha(Pilha *p);
void novaPilha(Pilha *p);

#endif
