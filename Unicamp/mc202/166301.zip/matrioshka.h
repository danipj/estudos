/* Nome: Daniela Palumbo
* RA: 166301
* Laboratorio 02 - Matrioshkas Generalizadas */

#ifndef MATRIOSHKA_H_
#define MATRIOSHKA_H_

#include <stdio.h>
#include <stdlib.h>
#include "pilha.h"

typedef struct Matrioshka {
	int tamanho;
	int fechada = 0; 
} Matrioshka


int fechaMatrioshka(Pilha *p);
