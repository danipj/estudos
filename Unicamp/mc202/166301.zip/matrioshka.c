/* Nome: Daniela Palumbo
* RA: 166301
* Laboratorio 02 - Matrioshkas Generalizadas */

#include "matrioshka.h"

int fechaMatrioshka(Pilha *p, int tam){
	/*desempilha topo e ve se ele fecha, se ele abre nao e matrioshka*/
	fecha = pop(*p);
	if (fecha<0)
		return 0;
	Pilha pB;
	novaPilha(pB);
	/*procura onde abre e empilha o que estiver no meio*/
	aux = pop(*p);
	/*achou metade*/
	if(aux+fecha==0){
		pop = pop(pB);
		if(pop!=0)
		/*tem algo dentro da matrioshka*/
		{	
			int soma = 0;
			/*conta tamanho do que tem no meio*/
			while (pop!=0)
			{	
				/*soma so as partes que fecham*/
				if(pop > 0)
					soma+= pop;
				pop = pop(pB);
			}
			if (soma < fecha)
			
		} 
	} else {
		push(pB,aux);
	}
}