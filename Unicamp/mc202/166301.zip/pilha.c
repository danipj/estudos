/* Nome: Daniela Palumbo
* RA: 166301
* Laboratorio 02 - Matrioshkas Generalizadas */

#include "pilha.h"

void push(Pilha *p, int k) {
    p->array[p->top++] = k;
}

int pop(Pilha *p) {
    return p->array[--p->top];
}

void novaPilha(Pilha* p) {
    p->top = 0;
}

void printPilha(Pilha *p) {
    for (int i = 0; i < p->top; ++i) {
        printf("%d ", p->array[i]);
    }
    printf("\n");
}