 /*
Daniela Palumbo 166301
Lab 04 - Caca Pixels
 */

#include <stdio.h>
#include "image.h"

typedef struct lista
{
    struct lista *prox;
    int value;
    int pos;
}Lista;

Lista* novoNo(int v, int p);
void insereComeco(Lista *lista,Lista *no);

int main()
{
    int maxEqual,beginInterval,endInterval,i,eq,count,freq;
    char* nomeImg;
    nomeImg = calloc(100,sizeof(char));
    Image *img;
    Lista* cor[256], *no;
    for (i=0;i<256;i++)
        cor[i]=NULL;

    /*ler a imagem, o intervalo e o maximo da equalizacao*/
    scanf("%s",nomeImg);
    scanf("%d %d %d", &maxEqual,&beginInterval,&endInterval);
    img = readImageP5(nomeImg);

    /*ordena vetor de pixel agrupando por pixels iguais*/
    for (i = img->n; i>=0; --i)
    { 
        /*cria um no pra esse pixel*/
        no = novoNo(img->pixel[i],i);
        /*acrescenta o no a cor correspondente*/
        insereComeco(cor[no->value],no);
        /*salva lista no vetor*/
        cor[no->value] = no;   
    }
    /*formula p equalizar*/
    freq = (float)img->n/(float)(maxEqual+1);
    eq=0;
    count=0;
    /*percorre o vetor pra achar pixels no intervalo*/
    for (i = 0; i < img->n; ++i)
    {   
        no = cor[i];
        while(no!=NULL){
            /*zera/avanca a cada range de equalizacao*/
            if(count==freq){
                eq++;
                count=0;
            }
            /*escreve a posicao do pixel no intervalo*/
            if(count>=beginInterval&&count<=endInterval)
                printf("%d ", no->pos);
            /*anda na lista*/
            no = no->prox;
            count++;
        }
    }
    
    return 0;
}

void insereComeco(Lista *lista,Lista *no){
    no->prox = lista;
}

Lista* novoNo(int v, int p){
    Lista* no = (Lista*) malloc(sizeof (Lista));
    //no->value = malloc ( v * sizeof (int));
    no->value = v;
    //no->pos = malloc ( p * sizeof (int));
    no->pos = p;
    no->prox = NULL;
    return no;    
}
